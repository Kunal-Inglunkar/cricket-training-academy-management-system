/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KUNAL
 */
class User {
    private int id;
    private String name, DOB,mobile_no,Email,Role;
    public User(int id, String name,String DOB,String mobile_no,String Email,String Role)
    {
        this.id=id;
        this.name=name;
        this.DOB=DOB;
        this.Email=Email;
        this.mobile_no=mobile_no;
        this.Role=Role;
        
    }

    User(int aInt, String string, String string0, String string1, String string2, String string3, String string4) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public int getid()
    {
        return id;
    }
    public String getName()
    {
        return name;
    }
     public String getdob()
    {
        return DOB;
    }
      public String getmobile()
    {
        return mobile_no;
    }
       public String getEmail()
    {
        return Email;
    }
        public String getRole()
    {
        return Role;
        
    }
        
        
}
